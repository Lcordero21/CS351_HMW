# CS351_HMW_Assignment-3
Base, BFS, DFS

Language: Python 3.13.2

How to run:
Click run in the program.py, in the terminal it will ask for you to input one of the Oregon cities in the list (which it will also print). It is important that you write it exactly as it's shown. The code is capitalization and underscore sensitive! If you don't write it exactly as shown, it will say the vertex couldn't be found...
